<html>
<!Created by Zhi Jie Huang>
<head>

<title> My Store Web Application </title>
<script
src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
 $('.button').click(function(){
 var clickBtnName = $(this).attr('name');
 var ajaxurl = 'http://localhost/SQLDeleteHandler.php';
 var data = {'id': clickBtnName};
 $.post(ajaxurl, data, function(response) {
  window.location.href="http://localhost/store.php";
});
});
});
</script>

</head>
<body>
<?php

//Obtain a connection object by connecting to the db

$connection = @mysqli_connect ('localhost', 'root', 'qq135897', 'lab5'); // please fill these parameters with the actual data
if(mysqli_connect_errno()){
 echo "<h4>Failed to connect to MySQL: </h4>".mysqli_connect_error();
}
else{
 echo "<h4>Successfully connected to MySQL: </h4>";
}

$query = "Select *from store;";
$resultset = mysqli_query($connection, $query);

echo "<table><tr><th>ID</th> <th>Name</th> <th>Quantity</th> <th>Price</th></tr>";
while ($row = mysqli_fetch_array($resultset, MYSQLI_NUM) ){
	echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td><input type=\"submit\" class=\"button\" name=\"".$row[0]."\"
value=\"delete\"/></td></tr>";
}
echo "</table>";
?>

<form enctype="multipart/form-data"
action="http://localhost/SQLInsertHandler.php">
<p>Id:&nbsp <input type="text" name="Id" size="10" maxlength="11"
/></p>
<p>Name:&nbsp <input type="text" name="Name" size="10"
maxlength="20" /></p>
<p>Quantity:&nbsp <input type="text" name="Quantity"
size="10" maxlength="30" /></p>
<p>Price:&nbsp <input type="text" name="Price" size="10"
maxlength="10" /></p>
<br>
<input type="submit" value="Add item" /> &nbsp
<input type="reset" />
</form>
</body>
</html>

