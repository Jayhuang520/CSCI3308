<?php
$Id = $_REQUEST['Id'];
$Name = $_REQUEST['Name'];
$Quantity = $_REQUEST['Quantity'];
$Price = $_REQUEST['Price'];

$connection = @mysqli_connect ('localhost', 'root', qq135897, 'lab5'); // please fill these parameters with the actual data

$query = "INSERT INTO store (id, name, qty, price) VALUES ('$Id','$Name', '$Quantity', '$Price');";

mysqli_query($connection, $query);
echo "Inserted successfully into the database";

include 'store.php';

?>

