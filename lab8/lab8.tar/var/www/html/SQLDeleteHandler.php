<?php
$id = $_REQUEST['id'];

$connection = @mysqli_connect ('localhost', 'root', qq135897, 'lab5'); // please fill these parameters with the actual data

$query = "delete from store where id='$id';";

mysqli_query($connection, $query);

include 'store.php';

?>

